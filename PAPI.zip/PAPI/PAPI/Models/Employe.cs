﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PAPI.Models
{
    public class Employe
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdEmploye { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateDeNaissance { get; set; }
        public virtual ICollection<Ordinateur> Ordinateurs { get; set; }
        public virtual ICollection<Adresse> Adresses { get; set; }
        public virtual ICollection<Numero> Numeros { get; set; }
    }
}
