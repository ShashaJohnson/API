﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PAPI.Models
{
    public class Ordinateur
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdOrdinateur { get; set; }
        public string NomOrdinateur { get; set; }
        public string Marque { get; set; }
        public int Stockage { get; set; }
        public int RAM { get; set; }
        public int IdEmploye { get; set; }
        [ForeignKey("IdEmploye")]
        public virtual Employe Employe { get; set; }

    }
}
