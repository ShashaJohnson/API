﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PAPI.Models
{
    public class Adresse
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdAdresse { get; set; }
        public string Ville { get; set; }
        public string Rue { get; set; }
        public int BoitePostale { get; set; }
        public int IdEmploye { get; set; }
        [ForeignKey("IdEmploye")]
        public virtual Employe Employe { get; set; }
    }
}
