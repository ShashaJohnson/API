﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PAPI.Models
{
    public class Numero
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IdNumero { get; set; }
        public int NumeroDeTelephone { get; set; }
        public string Fournisseur { get; set; }
        public int IdEmploye { get; set; }
        [ForeignKey("IdEmploye")]
        public virtual Employe Employe { get; set; }

    }
}
