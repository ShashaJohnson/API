﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PAPI.Data;
var builder = WebApplication.CreateBuilder(args);
//builder.Services.AddDbContext<PAPIContext>(options =>
//    options.MySqlServer(builder.Configuration.GetConnectionString("PAPIContext") ?? throw new InvalidOperationException("Connection string 'PAPIContext' not found.")));
var conString = builder.Configuration.GetConnectionString("EmployeAppCon");
Console.WriteLine(conString);

var serverVersion = new MySqlServerVersion(new Version(5, 7, 37));
builder.Services.AddDbContext<PAPIContext>(
           dbContextOptions => dbContextOptions
               .UseMySql(conString, serverVersion)
               .LogTo(Console.WriteLine, LogLevel.Information)
               .EnableSensitiveDataLogging()
               .EnableDetailedErrors()
       );
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
