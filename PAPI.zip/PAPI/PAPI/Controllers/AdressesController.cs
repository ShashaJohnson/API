﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PAPI.Data;
using PAPI.DTO;
using PAPI.Models;

namespace PAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdressesController : ControllerBase
    {
        private readonly PAPIContext _context;

        public AdressesController(PAPIContext context)
        {
            _context = context;
        }

        // GET: api/Adresses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Adresse>>> GetAdresse()
        {
          if (_context.Adresse == null)
          {
              return NotFound();
          }
            return await _context.Adresse.ToListAsync();
        }

        // GET: api/Adresses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Adresse>> GetAdresse(int id)
        {
          if (_context.Adresse == null)
          {
              return NotFound();
          }
            var adresse = await _context.Adresse.FindAsync(id);

            if (adresse == null)
            {
                return NotFound();
            }

            return adresse;
        }

        // PUT: api/Adresses/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdresse(int id, Adresse adresse)
        {
            if (id != adresse.IdAdresse)
            {
                return BadRequest();
            }

            _context.Entry(adresse).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdresseExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Adresses
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Adresse>> PostAdresse(AdresseRequest adresseRequest)
        {
            var adresse = new Adresse
            {
                IdAdresse=adresseRequest.IdAdresse,
                Ville = adresseRequest.Ville,
                Rue = adresseRequest.Rue,
                BoitePostale = adresseRequest.IdAdresse,
                IdEmploye = adresseRequest.EmployeId

            };
            if (_context.Adresse == null)
          {
              return Problem("Entity set 'PAPIContext.Adresse'  is null.");
          }
            _context.Adresse.Add(adresse);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AdresseExists(adresse.IdAdresse))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAdresse", new { id = adresse.IdAdresse }, adresse);
        }

        // DELETE: api/Adresses/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdresse(int id)
        {
            if (_context.Adresse == null)
            {
                return NotFound();
            }
            var adresse = await _context.Adresse.FindAsync(id);
            if (adresse == null)
            {
                return NotFound();
            }

            _context.Adresse.Remove(adresse);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AdresseExists(int id)
        {
            return (_context.Adresse?.Any(e => e.IdAdresse == id)).GetValueOrDefault();
        }
    }
}
