﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PAPI.Data;
using PAPI.DTO;
using PAPI.Models;

namespace PAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NumeroesController : ControllerBase
    {
        private readonly PAPIContext _context;

        public NumeroesController(PAPIContext context)
        {
            _context = context;
        }

        // GET: api/Numeroes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Numero>>> GetNumero()
        {
          if (_context.Numero == null)
          {
              return NotFound();
          }
            return await _context.Numero.ToListAsync();
        }

        // GET: api/Numeroes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Numero>> GetNumero(int id)
        {
          if (_context.Numero == null)
          {
              return NotFound();
          }
            var numero = await _context.Numero.FindAsync(id);

            if (numero == null)
            {
                return NotFound();
            }

            return numero;
        }

        // PUT: api/Numeroes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutNumero(int id, Numero numero)
        {
            if (id != numero.IdNumero)
            {
                return BadRequest();
            }

            _context.Entry(numero).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!NumeroExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Numeroes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Numero>> PostNumero(NumeroRequest numeroRequest)
        {
            var numero = new Numero
            {
                IdNumero = numeroRequest.IdNumero,
                NumeroDeTelephone = numeroRequest.NumeroDeTelephone,
                Fournisseur = numeroRequest.Fournisseur,
                IdEmploye = numeroRequest.IdEmploye

            };
            if (_context.Numero == null)
          {
              return Problem("Entity set 'PAPIContext.Numero'  is null.");
          }
            _context.Numero.Add(numero);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (NumeroExists(numero.IdNumero))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetNumero", new { id = numero.IdNumero }, numero);
        }

        // DELETE: api/Numeroes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteNumero(int id)
        {
            if (_context.Numero == null)
            {
                return NotFound();
            }
            var numero = await _context.Numero.FindAsync(id);
            if (numero == null)
            {
                return NotFound();
            }

            _context.Numero.Remove(numero);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool NumeroExists(int id)
        {
            return (_context.Numero?.Any(e => e.IdNumero == id)).GetValueOrDefault();
        }
    }
}
