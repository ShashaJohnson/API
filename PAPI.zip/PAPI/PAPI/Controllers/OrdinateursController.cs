﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PAPI.Data;
using PAPI.DTO;
using PAPI.Models;

namespace PAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdinateursController : ControllerBase
    {
        private readonly PAPIContext _context;

        public OrdinateursController(PAPIContext context)
        {
            _context = context;
        }

        // GET: api/Ordinateurs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Ordinateur>>> GetOrdinateur()
        {
          if (_context.Ordinateur == null)
          {
              return NotFound();
          }
            return await _context.Ordinateur.ToListAsync();
        }

        // GET: api/Ordinateurs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Ordinateur>> GetOrdinateur(int id)
        {
          if (_context.Ordinateur == null)
          {
              return NotFound();
          }
            var ordinateur = await _context.Ordinateur.FindAsync(id);

            if (ordinateur == null)
            {
                return NotFound();
            }

            return ordinateur;
        }

        // PUT: api/Ordinateurs/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrdinateur(int id, Ordinateur ordinateur)
        {
            if (id != ordinateur.IdOrdinateur)
            {
                return BadRequest();
            }

            _context.Entry(ordinateur).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrdinateurExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Ordinateurs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Ordinateur>> PostOrdinateur(OrdinateurRequest ordinateurRequest)
        {
            var ordinateur = new Ordinateur
            {
                IdOrdinateur = ordinateurRequest.IdOrdinateur,
                NomOrdinateur = ordinateurRequest.NomOrdinateur,
                Marque = ordinateurRequest.Marque,
                Stockage = ordinateurRequest.Stockage,
                RAM = ordinateurRequest.RAM,
                IdEmploye = ordinateurRequest.IdEmploye
            };
            if (_context.Ordinateur == null)
          {
              return Problem("Entity set 'PAPIContext.Ordinateur'  is null.");
          }
            _context.Ordinateur.Add(ordinateur);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OrdinateurExists(ordinateur.IdOrdinateur))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOrdinateur", new { id = ordinateur.IdOrdinateur }, ordinateur);
        }

        // DELETE: api/Ordinateurs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrdinateur(int id)
        {
            if (_context.Ordinateur == null)
            {
                return NotFound();
            }
            var ordinateur = await _context.Ordinateur.FindAsync(id);
            if (ordinateur == null)
            {
                return NotFound();
            }

            _context.Ordinateur.Remove(ordinateur);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrdinateurExists(int id)
        {
            return (_context.Ordinateur?.Any(e => e.IdOrdinateur == id)).GetValueOrDefault();
        }
    }
}
