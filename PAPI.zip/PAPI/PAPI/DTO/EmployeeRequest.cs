﻿namespace PAPI.DTO
{
    public class EmployeeRequest
    {
        public int IdEmploye { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateDeNaissance { get; set; }
    }
}
