﻿using PAPI.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace PAPI.DTO
{
    public class OrdinateurRequest
    {
        public int IdOrdinateur { get; set; }
        public string NomOrdinateur { get;  set; }
        public string Marque { get;  set; }
        public int Stockage { get;  set; }
        public int RAM { get; set; }
        public int IdEmploye { get; set; }
        //[ForeignKey("EmployeId")]
        //public virtual Employe Employe { get; set; }

    }
}
