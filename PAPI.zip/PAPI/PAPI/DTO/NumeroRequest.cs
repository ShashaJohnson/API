﻿namespace PAPI.DTO
{
    public class NumeroRequest
    {
        public int IdNumero { get; set; }
        public int NumeroDeTelephone { get; set; }
        public string Fournisseur { get; set; }
        public int IdEmploye { get; set; }

    }
}
