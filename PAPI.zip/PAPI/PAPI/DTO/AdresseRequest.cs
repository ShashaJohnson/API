﻿namespace PAPI.DTO
{
    public class AdresseRequest
    {
        public int IdAdresse { get; set; }
        public string Ville { get; set; }
        public string Rue { get; set; }
        public int BoitePostale { get; set; }
        public int IdEmploye { get; set; }

    }
}
