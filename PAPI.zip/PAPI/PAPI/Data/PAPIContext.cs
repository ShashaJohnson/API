﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PAPI.Models;

namespace PAPI.Data
{
    public class PAPIContext : DbContext
    {
        public PAPIContext (DbContextOptions<PAPIContext> options)
            : base(options)
        {
        }

        public DbSet<Adresse>? Adresse { get; set; }

        public DbSet<Numero>? Numero { get; set; }

        public DbSet<Ordinateur>? Ordinateur { get; set; }

        public DbSet<Employe>? Employe { get; set; }
    }
}
